import React, { useState } from "react";
import "./ProductCarousel.css";

function ProductCarousel({ products }) {
  const [startIndex, setStartIndex] = useState(0);
  const visibleCount = 3;

  const prev = () => {
    setStartIndex(startIndex === 0 ? 0 : startIndex - 1);
  };

  const next = () => {
    setStartIndex(
      startIndex + visibleCount >= products.length
        ? startIndex
        : startIndex + 1
    );
  };

  return (
    <div className="carousel-container">
      <button className="carousel-btn" onClick={prev} disabled={startIndex === 0}>
        &#8592;
      </button>
      <div className="carousel-products">
        {products
          .slice(startIndex, startIndex + visibleCount)
          .map((product, idx) => (
            <div key={idx} className="product-card">
              <img
                src={product.image}
                alt={product.name}
                className="product-image"
              />
              <div className="product-info">
                <h3>{product.name}</h3>
                <p>{product.price}</p>
              </div>
            </div>
          ))}
      </div>
      <button
        className="carousel-btn"
        onClick={next}
        disabled={startIndex + visibleCount >= products.length}
      >
        &#8594;
      </button>
    </div>
  );
}

export default ProductCarousel;