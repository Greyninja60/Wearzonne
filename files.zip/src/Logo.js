import React from "react";

function Logo() {
  return (
    <svg width="60" height="60" viewBox="0 0 60 60">
      <circle cx="30" cy="30" r="28" fill="#222" stroke="#fff" strokeWidth="3" />
      <text
        x="30"
        y="36"
        textAnchor="middle"
        fontSize="24"
        fill="#fff"
        fontFamily="sans-serif"
        fontWeight="bold"
      >
        US
      </text>
    </svg>
  );
}

export default Logo;