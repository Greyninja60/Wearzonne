import React from "react";
import ProductCarousel from "./ProductCarousel";
import Logo from "./Logo";
import "./App.css";

const products = [
  {
    name: "Classic Sweatshirt",
    image: "/images/sweatshirt1.jpg",
    price: "$29.99",
  },
  {
    name: "Graphic T-Shirt",
    image: "/images/tshirt1.jpg",
    price: "$19.99",
  },
  {
    name: "Oversized Hoodie",
    image: "/images/hoodie1.jpg",
    price: "$39.99",
  },
  {
    name: "Slim Fit Sweatpants",
    image: "/images/sweatpants1.jpg",
    price: "$34.99",
  },
  {
    name: "Denim Jacket",
    image: "/images/jacket1.jpg",
    price: "$49.99",
  },
  // Add more products as needed
];

function App() {
  return (
    <div className="app-container">
      <header>
        <Logo />
        <h1 className="brand-title">UrbanStyle</h1>
      </header>
      <section className="carousel-section">
        <h2>Shop Our Latest Collection</h2>
        <ProductCarousel products={products} />
      </section>
      <section className="info-section">
        <div className="about-us">
          <h2>About Us</h2>
          <p>
            UrbanStyle was founded with the vision to bring trendy, comfortable, and affordable fashion to everyone. Our founder, Alex Rivera, is passionate about sustainable clothing and urban culture.
          </p>
        </div>
        <div className="founder-contact">
          <h2>Founder & Contact Details</h2>
          <p>
            <strong>Founder:</strong> Alex Rivera<br />
            <strong>Email:</strong> contact@urbanstyle.com<br />
            <strong>Phone:</strong> +1 555-123-4567
          </p>
        </div>
        <div className="why-choose-us">
          <h2>Why Choose Us?</h2>
          <ul>
            <li>Trendy and comfortable designs</li>
            <li>Sustainable materials</li>
            <li>Affordable pricing</li>
            <li>Fast shipping and easy returns</li>
          </ul>
        </div>
      </section>
      <footer>
        &copy; {new Date().getFullYear()} UrbanStyle. All rights reserved.
      </footer>
    </div>
  );
}

export default App;